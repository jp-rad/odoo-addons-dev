__author__ = 'faide'

import logging
FORMAT = "%(asctime)-15s %(levelname)s %(module)s %(message)s"
logging.basicConfig(level=logging.INFO, format=FORMAT)

To be able to use this example please first successfully compile the juno driver in the
java/ folder.

When it is done you should be able to run this example if you have an openoffice server
listening somewhere and point this example on it...

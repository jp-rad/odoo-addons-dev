from ooservice import setup
setup()

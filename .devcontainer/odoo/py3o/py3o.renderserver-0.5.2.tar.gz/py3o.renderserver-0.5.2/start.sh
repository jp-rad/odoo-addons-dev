#!/bin/bash

start-py3o-renderserver --java=/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/amd64/server/libjvm.so --ure=/usr/lib/libreoffice --office=/usr/share --driver=juno --sofficeport=8997
